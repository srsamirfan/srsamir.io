/* =========================================================
   SAMIR PORTFOLIO
   SIMPLE COMPONENT LOADER
   =========================================================

   এই file-এর কাজ শুধু:

   1. Component fetch করা
   2. Component HTML বসানো
   3. Component-এর নিজের JS চালানো

   এখানে কোনো:
   - CSS change
   - Button change
   - Menu control
   - Grid control
   - Size control
   - Position control

   করা হবে না।
========================================================= */


async function loadComponents() {

    const components =
        document.querySelectorAll(
            "[data-component]"
        );


    for (const element of components) {

        const path =
            element.dataset.component;


        if (!path) {
            continue;
        }


        try {

            const response =
                await fetch(path, {
                    cache: "no-cache"
                });


            if (!response.ok) {

                throw new Error(
                    `HTTP ${response.status}`
                );

            }


            const html =
                await response.text();


            /*
             * Temporary container
             */

            const template =
                document.createElement(
                    "template"
                );


            template.innerHTML =
                html.trim();


            /*
             * Script collect
             */

            const scripts =
                Array.from(
                    template.content.querySelectorAll(
                        "script"
                    )
                );


            /*
             * Script remove
             *
             * কারণ innerHTML/replaceChildren দিয়ে
             * script automatic execute হয় না।
             */

            scripts.forEach(script => {
                script.remove();
            });


            /*
             * Component-এর HTML বসানো।
             *
             * CSS untouched থাকবে।
             */

            element.replaceChildren(
                template.content.cloneNode(true)
            );


            /*
             * Component-এর নিজের JS চালানো।
             */

            for (const oldScript of scripts) {

                const newScript =
                    document.createElement(
                        "script"
                    );


                /*
                 * সব original attributes রাখা হচ্ছে।
                 */

                for (
                    const attribute
                    of oldScript.attributes
                ) {

                    newScript.setAttribute(
                        attribute.name,
                        attribute.value
                    );

                }


                /*
                 * External JS
                 */

                if (oldScript.src) {

                    await new Promise(
                        (resolve, reject) => {

                            newScript.onload =
                                resolve;

                            newScript.onerror =
                                reject;

                            document.body.appendChild(
                                newScript
                            );

                        }
                    );

                }


                /*
                 * Inline JS
                 */

                else {

                    newScript.textContent =
                        oldScript.textContent;

                    document.body.appendChild(
                        newScript
                    );

                }

            }


            /*
             * Component loaded event
             */

            element.dispatchEvent(
                new CustomEvent(
                    "componentloaded",
                    {
                        detail: {
                            path: path
                        }
                    }
                )
            );


            console.log(
                "✓ Component loaded:",
                path
            );

        }


        catch (error) {

            console.error(
                "✕ Component failed:",
                path,
                error
            );

        }

    }

}



/* =========================================================
   START
========================================================= */

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        loadComponents
    );

}
else {

    loadComponents();

}