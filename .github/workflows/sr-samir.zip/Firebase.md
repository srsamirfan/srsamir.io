// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDQOB70S_RmaIuwxfftCbyC3BNN2xCcAzE",
  authDomain: "sr-samir-d9a2e.firebaseapp.com",
  databaseURL: "https://sr-samir-d9a2e-default-rtdb.firebaseio.com",
  projectId: "sr-samir-d9a2e",
  storageBucket: "sr-samir-d9a2e.firebasestorage.app",
  messagingSenderId: "504080172088",
  appId: "1:504080172088:web:4b12319244b282ba0b52cd",
  measurementId: "G-61WWNSTD96"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);